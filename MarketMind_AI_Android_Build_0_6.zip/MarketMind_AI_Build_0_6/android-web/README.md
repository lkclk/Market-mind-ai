See the project README one directory above for Android setup and API-key instructions.
