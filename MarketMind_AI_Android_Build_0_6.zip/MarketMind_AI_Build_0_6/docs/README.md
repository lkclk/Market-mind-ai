# MarketMind AI — Android Dashboard Build 0.6

## What this build does
- Mobile-friendly installable web dashboard for Android Chrome.
- External Twelve Data OHLC candles for EUR/USD, GBP/USD, USD/JPY, USD/CHF, AUD/USD, USD/CAD and NZD/USD.
- 5-minute, 15-minute, 1-hour and 4-hour analysis.
- EMA 20, RSI 14, ATR 14, recent support/resistance and rule-based BUY / SELL / WAIT labels.
- Sequential major-pair scanner and browser notifications when the page is open.
- Risk calculator initialized to the $10,000 USD demo-balance reference.
- Risk choices limited to 0.25%, 0.5% and 1.0%; 1.0% is the hard UI maximum.

## Start on Android
1. Create a free API key at https://twelvedata.com/.
2. Host the `android-web` folder on an HTTPS static host (for example GitHub Pages).
3. Open the HTTPS page in Chrome on Android.
4. In **Data & alerts setup**, paste the Twelve Data key and tap **Save key**.
5. Optionally tap **Enable notifications** and allow permission.
6. Tap **Analyse pair** or **Scan all majors**.
7. In Chrome's menu, choose **Add to Home screen**.

## Important limitations
- External Twelve Data quotes are not the HFM MT5 bid/ask feed. Prices and spreads can differ.
- This is a rule-based indicator dashboard, not a validated predictive AI model. Alignment scores are not win probabilities.
- No broker login, MT5 connection, VPS, order placement or automatic execution is included.
- It does not run reliably after Android suspends or closes the browser. Keep the page open for scans and alerts.
- The free provider plan and request limits can change. A seven-pair scan can consume multiple requests; avoid repeated scans.
- API key is stored in this browser's local storage. Do not share your phone/browser profile.
- The risk calculator is an estimate only. It does not calculate broker-specific lot sizes or guarantee that losses stay within 1%; gaps, slippage, spread, commissions and currency conversion can increase losses.

## HFM demo safety
Use the HFM MT5 app to confirm the demo account and all prices before considering any setup. This dashboard cannot see your HFM account balance or place demo trades. Automatic execution remains out of scope for this Android-only build.
