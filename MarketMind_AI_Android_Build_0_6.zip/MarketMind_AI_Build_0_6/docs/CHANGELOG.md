# Build 0.6 changes
- Initialized the risk calculator to the $10,000 USD demo reference.
- Removed risk selections above 1%; available values are 0.25%, 0.5% and 1%.
- Added an HFM demo workspace banner that clearly states the broker is not connected.
- Updated build label and setup/safety documentation.
- Kept execution and broker credential handling out of the Android dashboard.
